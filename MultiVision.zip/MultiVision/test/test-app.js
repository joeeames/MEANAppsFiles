angular.module('app', ['ngResource']);
var toastr = {};