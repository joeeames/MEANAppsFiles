To run this application, start your mongo server & do the following from the command line:
bower install
npm install
nodemon server.js